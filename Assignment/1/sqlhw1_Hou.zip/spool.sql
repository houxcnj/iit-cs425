PHONE      
------------
312-555-9403 

F_NAME                         L_NAME                         DESCRIPTION                                                
------------------------------ ------------------------------ ------------------------------------------------------------
April                          O’Shea                         Knitting, sewing, ect                                        

F_NAME                         L_NAME                       
------------------------------ ------------------------------
Annie                          Heard                          

F_NAME                         L_NAME                         DESCRIPTION                                                
------------------------------ ------------------------------ ------------------------------------------------------------
Abby                           Smith                          Knitting, sewing, ect                                        
Victor                         Garcia                         Paining, sculpting, ect                                      
Victor                         Garcia                         Anything to do with writing, literature, or communication    
Abby                           Smith                          Courses geared towards children 13 and younger               
Abby                           Smith                          Any courses having to do with physical activity              
Abby                           Smith                          Paining, sculpting, ect                                      
Abby                           Smith                          Any courses having to do with physical activity              
Harry                          Tang                           Knitting, sewing, ect                                        
Harry                          Tang                           Paining, sculpting, ect                                      
Harry                          Tang                           Anything to do with writing, literature, or communication    
Victor                         Garcia                         Courses geared towards children 13 and younger               

 11 rows selected 

F_NAME                         L_NAME                          FAMILY_ID DESCRIPTION                                                
------------------------------ ------------------------------ ---------- ------------------------------------------------------------
Justin                         Smith                                   1 Courses geared towards children 13 and younger               
Abby                           Smith                                   1 Courses geared towards children 13 and younger               

AVG(H.AGE)
----------
25.1333333 
      64.4 

